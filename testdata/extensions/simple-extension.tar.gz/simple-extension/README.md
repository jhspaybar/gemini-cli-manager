# Simple Test Extension

This is a test extension used for unit tests.